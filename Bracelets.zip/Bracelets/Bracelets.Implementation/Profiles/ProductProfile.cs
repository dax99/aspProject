﻿using AutoMapper;
using Bracelets.Application.DataTransfer;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Profiles
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<Domain.Product, ProductDto>();
        }
    }
}
