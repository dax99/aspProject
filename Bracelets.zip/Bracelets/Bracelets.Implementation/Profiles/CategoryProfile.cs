﻿using AutoMapper;
using Bracelets.Application.DataTransfer;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Profiles
{
    public class CategoryProfile : Profile
    {
        public CategoryProfile()
        {
            CreateMap<Domain.Category, CategoryDto>();
        }
    }
}
