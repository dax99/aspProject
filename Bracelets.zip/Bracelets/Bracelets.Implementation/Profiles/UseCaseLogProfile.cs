﻿using AutoMapper;
using Bracelets.Application.DataTransfer;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Profiles
{
    public class UseCaseLogProfile : Profile
    {
        public UseCaseLogProfile()
        {
            CreateMap<Domain.UseCaseLog, UseCaseLogDto>();
        }
    }
}
