﻿using Bracelets.Application.Commands;
using Bracelets.Application.DataTransfer;
using Bracelets.DataAccess;
using Bracelets.Domain;
using Bracelets.Implementation.Validators;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Commands
{
    public class EfCreateOrderCommand : ICreateOrderCommand
    {
        private readonly BraceletsContext _context;
        private readonly CreateOrderValidator _validator;

        public EfCreateOrderCommand(BraceletsContext context, CreateOrderValidator validator)
        {
            _context = context;
            _validator = validator;
        }
        public int Id => 8;

        public string Name => "Create order";

        public void Execute(OrderDto request)
        {
            _validator.ValidateAndThrow(request);
            var order = new Order
            {
                UserId = request.UserId,
                Address = request.Address,
                OrderDate = request.OrderDate
            };

            foreach (var item in request.Items)
            {
                var product = _context.Products.Find(item.ProductId);

                order.OrderLines.Add(new OrderLine
                {
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    Name = product.Name,
                    Price = product.Price
                });
            }

            _context.Orders.Add(order);
            _context.SaveChanges();
        }
    }
}
