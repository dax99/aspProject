﻿using Bracelets.Application.Commands;
using Bracelets.Application.DataTransfer;
using Bracelets.DataAccess;
using Bracelets.Domain;
using Bracelets.Implementation.Validators;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Commands
{
    public class EfCreateCategoryCommand : ICreateCategoryCommand
    {
        private readonly BraceletsContext _context;
        private readonly CreateCategoryValidator _validator;

        public EfCreateCategoryCommand(BraceletsContext context, CreateCategoryValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        public int Id => 1;

        public string Name => "Create New Category";

        public void Execute(CategoryDto request)
        {
            _validator.ValidateAndThrow(request);
            var category = new Category
            {
                Name = request.Name
            };

            _context.Categories.Add(category);

            _context.SaveChanges();
        }
    }
}
