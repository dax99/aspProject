﻿using Bracelets.Application.Commands.Product;
using Bracelets.Application.DataTransfer;
using Bracelets.DataAccess;
using Bracelets.Domain;
using Bracelets.Implementation.Validators;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Commands
{
    public class EfCreateProductCommand : ICreateProductCommand
    {
        private readonly BraceletsContext _context;
        private readonly CreateProductValidator _validator;

        public EfCreateProductCommand(BraceletsContext context, CreateProductValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        public int Id => 10;

        public string Name => "Create New Product";

        public void Execute(ProductDto request)
        {
            _validator.ValidateAndThrow(request);
            var product = new Product
            {
                Name = request.Name,
                Price = request.Price,
                Description = request.Description,
                Image = request.Image,
                CategoryId = request.CategoryId
            };

            _context.Products.Add(product);

            _context.SaveChanges();
        }
    }
}
