﻿using Bracelets.Application.Commands.Category;
using Bracelets.Application.Exceptions;
using Bracelets.DataAccess;
using Bracelets.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Commands
{
    public class EfDeleteCategoryCommand : IDeleteCategoryCommand
    {
        private readonly BraceletsContext _context;

        public EfDeleteCategoryCommand(BraceletsContext context)
        {
            this._context = context;
        }

        public int Id => 2;

        public string Name => "Category Delete";

        public void Execute(int request)
        {
            var category = _context.Categories.Find(request);

            if (category == null)
            {
                throw new EntityNotFoundException(request, typeof(Category));
            }
            category.IsDeleted = true;
            category.ModifiedAt = DateTime.Now;
            //_context.Categories.Remove(category);

            _context.SaveChanges();
        }
    }
}
