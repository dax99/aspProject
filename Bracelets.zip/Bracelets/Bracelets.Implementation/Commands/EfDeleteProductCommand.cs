﻿using Bracelets.Application.Commands.Product;
using Bracelets.Application.Exceptions;
using Bracelets.DataAccess;
using Bracelets.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Commands
{
    public class EfDeleteProductCommand : IDeleteProductCommand
    {
        private readonly BraceletsContext _context;

        public EfDeleteProductCommand(BraceletsContext context)
        {
            this._context = context;
        }
        public int Id => 7;

        public string Name => "Product Delete";

        public void Execute(int request)
        {
            var product = _context.Products.Find(request);

            if (product == null)
            {
                throw new EntityNotFoundException(request, typeof(Product));
            }
            product.IsDeleted = true;
            product.ModifiedAt = DateTime.Now;

            _context.SaveChanges();
        }
    }
}
