﻿using AutoMapper;
using Bracelets.Application.DataTransfer;
using Bracelets.Application.Queries;
using Bracelets.Application.Searches;
using Bracelets.DataAccess;
using Bracelets.Implementation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bracelets.Implementation.Queries
{
    public class EfGetCategoriesQuery : IGetCategoriesQuery
    {
        private readonly BraceletsContext context;
        private readonly IMapper _mapper;

        public EfGetCategoriesQuery(BraceletsContext context, IMapper mapper)
        {
            this.context = context;
            _mapper = mapper;
        }

        public int Id => 4;

        public string Name => "Search Category";

        public PagedResponse<CategoryDto> Execute(CategorySearch search)
        {
            var query = context.Categories.AsQueryable();

            if (!string.IsNullOrEmpty(search.Name) || !string.IsNullOrWhiteSpace(search.Name))
            {
                query = query.Where(x => x.Name.ToLower().Contains(search.Name.ToLower()));
            }

            return query.Paged<CategoryDto, Domain.Category>(search, _mapper);
        }
    }
}
