﻿using AutoMapper;
using Bracelets.Implementation.Extensions;
using Bracelets.Application.DataTransfer;
using Bracelets.Application.Exceptions;
using Bracelets.Application.Queries;
using Bracelets.Application.Searches;
using Bracelets.DataAccess;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bracelets.Implementation.Queries
{
    public class EfGetProductsQuery : IGetProductsQuery
    {
        private readonly BraceletsContext context;
        private readonly IMapper _mapper;

        public EfGetProductsQuery(BraceletsContext context, IMapper mapper)
        {
            this.context = context;
            _mapper = mapper;
        }
        public int Id => 6;

        public string Name => "Search Products";

        public PagedResponse<ProductDto> Execute(ProductSearch search)
        {

            //var query = context.Products.Include(x => x.Category).AsQueryable();
            var query = context.Products.AsQueryable();

            if (!string.IsNullOrEmpty(search.Name) || !string.IsNullOrWhiteSpace(search.Name))
            {
                query = query.Where(x => x.Name.ToLower().Contains(search.Name.ToLower()));
            }
            if (search.CategoryId > 0)
            {
                query = query.Where(x => x.CategoryId == search.CategoryId);
            }
            if (search.PriceFrom > 0)
            {
                query = query.Where(x => x.Price >= search.PriceFrom);
            }
            if (search.PriceTo > 0)
            {
                query = query.Where(x => x.Price <= search.PriceTo);

                if (search.PriceTo < search.PriceFrom)
                {
                    throw new PriceFromToException();
                }
            }
            

            return query.Paged<ProductDto, Domain.Product>(search, _mapper);
        }
    }
}
