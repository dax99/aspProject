﻿using AutoMapper;
using Bracelets.Application.DataTransfer;
using Bracelets.Application.Exceptions;
using Bracelets.Application.Queries;
using Bracelets.Application.Searches;
using Bracelets.DataAccess;
using Bracelets.Implementation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bracelets.Implementation.Queries
{
    public class EfGetUseCaseLogsQuery : IGetUseCaseLogsQuery
    {
        private readonly BraceletsContext context;
        private readonly IMapper _mapper;

        public EfGetUseCaseLogsQuery(BraceletsContext context, IMapper mapper)
        {
            this.context = context;
            _mapper = mapper;
        }
        public int Id => 5;

        public string Name => "Search Logs";

        public PagedResponse<UseCaseLogDto> Execute(UseCaseLogSearch search)
        {
            var query = context.UseCaseLogs.AsQueryable();

            if (!string.IsNullOrEmpty(search.Actor) || !string.IsNullOrWhiteSpace(search.Actor))
            {
                query = query.Where(x => x.Actor.ToLower().Contains(search.Actor.ToLower()));
            }
            if (!string.IsNullOrEmpty(search.UseCaseName) || !string.IsNullOrWhiteSpace(search.UseCaseName))
            {
                query = query.Where(x => x.UseCaseName.ToLower().Contains(search.UseCaseName.ToLower()));
            }
            if (search.DateFrom != DateTime.MinValue)
            {
                query = query.Where(x => x.Date >= search.DateFrom);
            }
            if (search.DateTo != DateTime.MinValue && search.DateTo >= search.DateFrom)
            {
                query = query.Where(x => x.Date <= search.DateTo);
            }
            if (search.DateTo < search.DateFrom)
            {
                throw new DateFromToException();
            }

            return query.Paged<UseCaseLogDto, Domain.UseCaseLog>(search, _mapper);
        }
    }
}
