﻿using Bracelets.Application.DataTransfer;
using Bracelets.DataAccess;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bracelets.Implementation.Validators
{
    public class RegisterUserValidator : AbstractValidator<RegisterUserDto>
    {

        public RegisterUserValidator(BraceletsContext context)
        {
            RuleFor(x => x.FirstName).NotEmpty();
            RuleFor(x => x.LastName).NotEmpty();
            RuleFor(x => x.Password)
                .NotEmpty()
                .MinimumLength(6);

            RuleFor(x => x.Username)
                .NotEmpty()
                .MinimumLength(3)
                .Must(x => !context.Users.Any(user => user.Username == x))
                .WithMessage("Username already exists.");

            RuleFor(x => x.Email)
                .NotEmpty()
                .EmailAddress();

        }
    }
}
