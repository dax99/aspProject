﻿using Bracelets.Application.DataTransfer;
using Bracelets.DataAccess;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bracelets.Implementation.Validators
{
    public class CreateOrderValidator : AbstractValidator<OrderDto>
    {
        private readonly BraceletsContext _context;

        public CreateOrderValidator(BraceletsContext context)
        {
            _context = context;
            RuleFor(x => x.Address)
                .NotEmpty()
                .WithMessage("Address must be entered");
            RuleFor(x => x.OrderDate).
                GreaterThan(DateTime.Today)
                .WithMessage("Order date must be in future.")
                .LessThan(DateTime.Now.AddDays(30))
                .WithMessage("Order date can't be more than 30 days from today.");
            RuleFor(x => x.Items)
               .NotEmpty()
               .WithMessage("There must be at least one order line.")
               .Must(i => i.Select(x => x.ProductId).Distinct().Count() == i.Count())
               .WithMessage("Duplicate products are not allowed.")
               .DependentRules(() =>
               {
                   RuleForEach(x => x.Items).SetValidator
                       (new CreateOrderLineValidator(_context));
               });
        }
    }
}
