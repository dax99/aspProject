﻿using Bracelets.Application.DataTransfer;
using Bracelets.DataAccess;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bracelets.Implementation.Validators
{
    public class CreateProductValidator : AbstractValidator<ProductDto>
    {
        private readonly BraceletsContext _context;
        public CreateProductValidator(BraceletsContext context)
        {
            _context = context;

            RuleFor(x => x.Name)
                .NotEmpty()
                .WithMessage("Name is required parameter.")
                .Must(name => !_context.Products.Any(p => p.Name == name))
                .WithMessage(p => $"Product with the name of {p.Name} already exists in database.");

            RuleFor(x => x.Price)
                .GreaterThan(0)
                .WithMessage("Price must be above 0.");
        }
    }
}
