﻿using Bracelets.Application.DataTransfer;
using Bracelets.DataAccess;
using FluentValidation;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Implementation.Validators
{
    public class CreateOrderLineValidator : AbstractValidator<OrderLineDto>
    {
        private readonly BraceletsContext context;
        public CreateOrderLineValidator(BraceletsContext context)
        {
            this.context = context;


            RuleFor(x => x.ProductId)
                .Must(ProductExists)
                .WithMessage("Product with an id of {PropertyValue} doesn't exist.")
                .DependentRules(() =>
                {
                    RuleFor(x => x.Quantity)
                    .GreaterThan(0)
                    .WithMessage("Quantity must be greater than 0");
                });
        }
        private bool ProductExists(int productId)
        {
            return context.Products.Any(x => x.Id == productId);
        }
    }
}
