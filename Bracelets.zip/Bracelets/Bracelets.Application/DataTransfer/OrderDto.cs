﻿using Bracelets.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.DataTransfer
{
    public class OrderDto
    {
        public int UserId { get; set; }
        public DateTime OrderDate { get; set; }
        public string Address { get; set; }

        public virtual ICollection<OrderLine> OrderLines { get; set; } = new HashSet<OrderLine>();
        public IEnumerable<OrderLineDto> Items { get; set; } = new List<OrderLineDto>();
        public virtual User User { get; set; }
    }
}
