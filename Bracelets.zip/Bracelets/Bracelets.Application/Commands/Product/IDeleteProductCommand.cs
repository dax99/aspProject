﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Commands.Product
{
    public interface IDeleteProductCommand : ICommand<int>
    {
    }
}
