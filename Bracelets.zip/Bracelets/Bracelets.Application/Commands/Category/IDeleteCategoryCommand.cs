﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Commands.Category
{
    public interface IDeleteCategoryCommand : ICommand<int>
    {
    }
}
