﻿using Bracelets.Application.DataTransfer;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Commands
{
    public interface ICreateOrderCommand : ICommand<OrderDto>
    {
    }
}
