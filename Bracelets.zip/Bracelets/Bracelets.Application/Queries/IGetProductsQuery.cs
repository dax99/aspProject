﻿using Bracelets.Application.DataTransfer;
using Bracelets.Application.Searches;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Queries
{
    public interface IGetProductsQuery : IQuery<ProductSearch, PagedResponse<ProductDto>>
    {
    }
}
