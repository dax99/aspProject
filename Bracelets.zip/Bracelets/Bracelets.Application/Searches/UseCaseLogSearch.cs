﻿using Bracelets.Application.Queries;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Searches
{
    public class UseCaseLogSearch : PagedSearch
    {
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public string UseCaseName { get; set; }
        public string Actor { get; set; }
    }
}
