﻿using Bracelets.Application.Queries;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Searches
{
    public class ProductSearch : PagedSearch
    {
        public string Name { get; set; }
        public decimal PriceFrom { get; set; }
        public decimal PriceTo { get; set; }
        public int? CategoryId { get; set; }
    }
}
