﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Exceptions
{
    public class DateFromToException : Exception
    {
        public DateFromToException()
            : base($"Date From can't be larger than Date To!")
        {
        }
    }
}
