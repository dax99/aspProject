﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Exceptions
{
    public class PriceFromToException : Exception
    {
        public PriceFromToException()
            : base($"Price From can't be larger than Price To!")
        {
        }
    }
}
