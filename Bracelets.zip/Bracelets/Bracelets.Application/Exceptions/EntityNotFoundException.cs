﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Exceptions
{
    public class EntityNotFoundException : Exception
    {
        public EntityNotFoundException(int id, Type type)
            : base($"Entity {type.Name} with Id: {id} was not found.")
        {
        }
    }
}
