﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Application.Exceptions
{
    public class UnauthorizedUseCaseException : Exception
    {
        public UnauthorizedUseCaseException(IUseCase useCase, IApplicationActor actor)
            : base($"Actor {actor.Identity} tried to execute {useCase.Name}.")
        {
        }
    }
}
