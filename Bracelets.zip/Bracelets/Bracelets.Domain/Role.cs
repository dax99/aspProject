﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.Domain
{
    public class Role : Entity
    {
        public static int DefaultRoleId => 1;
        public string Name { get; set; }
        public ICollection<User> Users { get; set; }
    }
}
