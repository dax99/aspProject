﻿using Bracelets.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bracelets.DataAccess.Configurations
{
    public class UserConfiguration : IEntityTypeConfiguration<User>
    {
        public void Configure(EntityTypeBuilder<User> builder)
        {
            builder.Property(p => p.Username).HasMaxLength(50).IsRequired();
            builder.HasIndex(p => p.Username).IsUnique();

            builder.Property(p => p.Email).HasMaxLength(80).IsRequired();
            builder.HasIndex(p => p.Email).IsUnique();

            builder.Property(p => p.FirstName).HasMaxLength(40).IsRequired();
            builder.Property(p => p.LastName).HasMaxLength(40).IsRequired();
            builder.Property(p => p.Password).HasMaxLength(60).IsRequired();

            builder.Property(u => u.CreatedAt).HasDefaultValueSql("GETDATE()");

            //builder.HasMany(c => c.CategoryProducts)
            //    .WithOne(cp => cp.Category)
            //    .HasForeignKey(cp => cp.CategoryId)
            //    .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
