﻿using Bracelets.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bracelets.DataAccess
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(
                   new User
                   {
                       Id = 9,
                       FirstName = "Mika",
                       LastName = "Mikic",
                       Username = "mika",
                       Password = "mika1",
                       Email = "mika@gmail.com"
                   },
                   new User
                   {
                       Id = 10,
                       FirstName = "Pera",
                       LastName = "Admin",
                       Username = "admin1",
                       Password = "admin1",
                       Email = "admin1@gmail.com"
                   },
                   new User
                   {
                       Id = 11,
                       FirstName = "Zika",
                       LastName = "Zikic",
                       Username = "zika",
                       Password = "zika1",
                       Email = "zika@gmail.com"
                   }
            );
            modelBuilder.Entity<UserUseCase>().HasData(
                new UserUseCase
                {
                    Id = 15,
                    UserId = 9,
                    UseCaseId = 4
                },
                 new UserUseCase
                 {
                     Id = 16,
                     UserId = 9,
                     UseCaseId = 6
                 },
                 new UserUseCase
                 {
                     Id = 17,
                     UserId = 11,
                     UseCaseId = 4
                 },
                 new UserUseCase
                 {
                     Id = 18,
                     UserId = 11,
                     UseCaseId = 6
                 }
            );
            for (int i = 0; i < 11; i++)
            {
                modelBuilder.Entity<UserUseCase>().HasData(
                    new UserUseCase
                    {
                        Id = 19 + i,
                        UserId = 10,
                        UseCaseId = i+1
                    }
                );
            }
            for (int i = 0; i < 10; i++)
            {
                modelBuilder.Entity<Category>().HasData(
                    new Category
                    {
                        Id = 7 + i,
                        Name = "Category" + i
                    }
                );
            }
            Random rnd = new Random();
            for (int i = 0; i < 10; i++)
            {
                modelBuilder.Entity<Product>().HasData(
                    new Product
                    {
                        Id = 8 + i,
                        Name = "Product" + i,
                        Description = "Description" + i,
                        Price = 10 + rnd.Next(1, 15),
                        CategoryId = rnd.Next(7, 15)
                    }
                );
            }
            for (int i = 0; i < 2; i++)
            {
                modelBuilder.Entity<Order>().HasData(
                    new Order
                    {
                        Id = 3 + i,
                        UserId = 10 + i,
                        Address = "Address" + i,
                        OrderDate = DateTime.Now
                    }
                );
            }
            for (int i = 0; i < 4; i++)
            {
                modelBuilder.Entity<OrderLine>().HasData(
                    new OrderLine
                    {
                        Id = 3 + i,
                        Name = "Order line" + i,
                        Quantity = rnd.Next(1,5),
                        Price = rnd.Next(15, 50),
                        OrderId = rnd.Next(3,4),
                        ProductId = rnd.Next(8, 15)
                    }
                );
            }
        }
    }
}
