﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Bracelets.DataAccess.Migrations
{
    public partial class Userseed : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "FirstName", "IsDeleted", "LastName", "ModifiedAt", "Password", "Username" },
                values: new object[] { 9, "mika@gmail.com", "Mika", false, "Mikic", null, "mika1", "mika" });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "FirstName", "IsDeleted", "LastName", "ModifiedAt", "Password", "Username" },
                values: new object[] { 10, "admin1@gmail.com", "Pera", false, "Admin", null, "admin1", "admin1" });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "Email", "FirstName", "IsDeleted", "LastName", "ModifiedAt", "Password", "Username" },
                values: new object[] { 11, "zika@gmail.com", "Zika", false, "Zikic", null, "zika1", "zika" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 11);
        }
    }
}
