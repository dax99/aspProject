﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Bracelets.DataAccess.Migrations
{
    public partial class Usecaseseed : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "UserUseCase",
                columns: new[] { "Id", "UseCaseId", "UserId" },
                values: new object[,]
                {
                    { 15, 4, 9 },
                    { 16, 6, 9 },
                    { 17, 4, 11 },
                    { 18, 6, 11 },
                    { 19, 1, 10 },
                    { 20, 2, 10 },
                    { 21, 3, 10 },
                    { 22, 4, 10 },
                    { 23, 5, 10 },
                    { 24, 6, 10 },
                    { 25, 7, 10 },
                    { 26, 8, 10 },
                    { 27, 9, 10 },
                    { 28, 10, 10 },
                    { 29, 11, 10 }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 24);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 25);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 26);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 27);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 28);

            migrationBuilder.DeleteData(
                table: "UserUseCase",
                keyColumn: "Id",
                keyValue: 29);
        }
    }
}
